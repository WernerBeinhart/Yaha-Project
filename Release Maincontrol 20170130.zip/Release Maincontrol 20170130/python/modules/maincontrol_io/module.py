#!/usr/bin/env python
# -*- coding: utf-8 -*-
#python /home/pi/Yaha/yaha_main.py

def init(PDI):
    pass

def update(PDI):
    pass
