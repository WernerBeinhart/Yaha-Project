import sys
sys.path.append("/home/pi/Yaha/modules/weather")